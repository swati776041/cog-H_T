import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { UserAuthService } from './user-auth.service';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  private host: string = "http://ec2-18-181-85-188.ap-northeast-1.compute.amazonaws.com:8081";
  requestHeader = new HttpHeaders(
    { "NO-Auth": "True" }
  );
  constructor(private http: HttpClient, private userAuthService: UserAuthService) { }

  public login(loginData: any) {
    return this.http.post(this.host + '/authenticate/login', loginData, {
      headers: this.requestHeader
    });

  }
  //public roleMatch(allowedRoles: any) {
    //  let isMatch=false;
    //return this.userAuthService.getRoles() === "AUTHOR" ? true : false;
    //  if(userRole && userRole === "AUTHOR") return true;

    //      for(let i=0; i<userRoles.length; i++){
    //         for(let j=0; j<allowedRoles.length; j++){
    //           if(userRoles[i].roleName === allowedRoles[j]){
    //       isMatch=true;
    //      return isMatch;
    //     }else{
    //       return isMatch;
    //     }
    //   }
    //  }
    // else return false;  
  //}

}

