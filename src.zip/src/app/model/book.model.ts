export interface Book{
    title:string,
	category: String,
	image : String ,
    price:number ,
	publishDate: String ,
    publisher: String,
    active:Boolean ,
	content: String ,
	authorId:number,
}