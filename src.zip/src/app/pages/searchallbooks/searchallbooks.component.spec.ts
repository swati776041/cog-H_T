import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchallbooksComponent } from './searchallbooks.component';

describe('SearchallbooksComponent', () => {
  let component: SearchallbooksComponent;
  let fixture: ComponentFixture<SearchallbooksComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SearchallbooksComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SearchallbooksComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
