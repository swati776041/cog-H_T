import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Book } from '../model/book.model';

@Injectable({
  providedIn: 'root'
})
export class BookService {

  constructor(private httpClient:HttpClient) { }

  public addBook(book:Book){
    return this.httpClient.post<Book>("http://ec2-35-78-210-202.ap-northeast-1.compute.amazonaws.com:8081/digitalbook/author/1/book", book);
  }
  public getAllBooks(){
    return this.httpClient.get<Book>("http://ec2-35-78-210-202.ap-northeast-1.compute.amazonaws.com:8081/digitalbooks/search/books")
  }
  public blockBook(book:Book){
    return this.httpClient.post<Book>("http://ec2-35-78-210-202.ap-northeast-1.compute.amazonaws.com:8081/digitalbook/author/1/book/1/blockyes", book);
  }
  public editBook(book:Book){
    return this.httpClient.post<Book>("http://ec2-35-78-210-202.ap-northeast-1.compute.amazonaws.com:8081/digitalbook/author/1/book/1/", book);
  }
  public deleteBook(id:number){
    return this.httpClient.delete("http://ec2-35-78-210-202.ap-northeast-1.compute.amazonaws.com:8081/digitalbook/author/1/book/delete/1/"+id)
  }
}
