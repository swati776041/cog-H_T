import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Book } from 'src/app/model/book.model';
import { BookService } from 'src/app/services/book.service';

@Component({
  selector: 'app-searchallbooks',
  templateUrl: './searchallbooks.component.html',
  styleUrls: ['./searchallbooks.component.css']
})
export class SearchallbooksComponent implements OnInit {
  bookDetails:Book[]=[];
  displayedColumns: string[] = [ 'title', 'category', 'image','price','publishDate',
'publisher','active','content','authorId'];
  SearchallbooksComponent: any;
  // book:Book={
  //   title:'',
	// category: '',
	// image : '' ,
  //   price:0 ,
	// publishDate: '' ,
  //   publisher: '', 
	// content: '' ,
	// authorId:0,
  // active: true
  // }
constructor(private bookService:BookService){}
  ngOnInit() : void{
this.getAllBooks();
  }
  public getAllBooks(){
    this.bookService.getAllBooks().subscribe(
      (response:any)=>{
        console.log(response);
        this.SearchallbooksComponent.bookDetails=response;
        
      },
      (error:HttpErrorResponse) =>{
        console.log(error);
        
      }
    );
  }
  deleteBook(id:any){
    this.bookService.deleteBook(id).subscribe(
      (resp)=>{
       this.getAllBooks ();
      },
      (error:HttpErrorResponse)=>{
        console.log(error);
        
      }
    );
    
  }

}
