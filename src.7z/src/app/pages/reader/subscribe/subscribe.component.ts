import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Subscription } from 'src/app/model/subscription';
import { SubscriptionService } from 'src/app/services/subscription.service';

@Component({
  selector: 'app-subscribe',
  templateUrl: './subscribe.component.html',
  styleUrls: ['./subscribe.component.css']
})
export class SubscribeComponent implements OnInit{
  subscription:Subscription={
    date:'',
	time: '',
	bookID :0,
  authotId:0
  
  }
constructor(private subscriptionService: SubscriptionService){

}
ngOnInit():void{

}
subscribeBook(subscriptionForm:NgForm){
  this.subscriptionService.subscribeBook(this.subscription).subscribe(
    (response:Subscription) =>{
   console.log(response);
    },
    (error:HttpErrorResponse)=>{
      console.log(error);
      
    }
  );

  
}
}
