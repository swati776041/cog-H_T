package com.java.bookservice.Bookservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookservicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookservicesApplication.class, args);
	}

}
