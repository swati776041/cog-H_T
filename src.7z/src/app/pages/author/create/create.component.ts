import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Book } from 'src/app/model/book.model';
import {  BookService } from 'src/app/services/book.service';
@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {
  book:Book={
    title:'',
	category: '',
	image : '' ,
    price:0 ,
	publishDate: '' ,
    publisher: '', 
	content: '' ,
	authorId:0,
  active: true
  }
constructor(private bookService: BookService){

}
ngOnInit():void{

}
addBook(bookForm:NgForm){
  this.bookService.addBook(this.book).subscribe(
    (response:Book) =>{
      console.log(response);
      
      // bookForm.reset();
    },
    (error:HttpErrorResponse)=>{
      console.log(error);
      
    }
  );

  
}
}
