export interface Subscription{
    date: String,
	time: String,
	bookID: number,
	authotId:number

}