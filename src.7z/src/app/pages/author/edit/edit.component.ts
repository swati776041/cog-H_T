import { HttpErrorResponse } from '@angular/common/http';
import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Book } from 'src/app/model/book.model';
import { BookService } from 'src/app/services/book.service';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent {
  book:Book={
    title:'',
	category: '',
	image : '' ,
    price:0 ,
	publishDate: '' ,
    publisher: '', 
	content: '' ,
	authorId:0,
  active: true
  }
constructor(private bookService: BookService){

}
ngOnInit():void{

}
editBook(bookForm:NgForm){
  this.bookService.editBook(this.book).subscribe(
    (response:Book) =>{
      bookForm.reset();
    },
    (error:HttpErrorResponse)=>{
      console.log(error);
      
    }
  );

  
}

}
