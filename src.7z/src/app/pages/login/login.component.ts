import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/services/login.service';
import { UserAuthService } from 'src/app/services/user-auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit{
  loginData={
    username:'',
    password:'',
  };
  constructor( private loginService:LoginService, private userAuthService:UserAuthService,
    private router:Router){}
  
     ngOnInit():void{}

     login(loginForm:NgForm){
      this.loginService.login(loginForm.value).subscribe(
        (response:any)=>{
          console.log(response);
            this.userAuthService.setToken(response.token);
this.userAuthService.setRoles(response.role);
           const role:string= response.role;
     if(role.includes('AUTHOR')){
this.router.navigate(['/author']);
     }else{
      this.router.navigate(['/reader']);
     }
          },
          (error)=>{
            console.log(error);
            
          }
      );
       
     }
//      formSubmit(){
//        console.log('login btn clicked');
//        if(this.loginData.username.trim()==''||this.loginData.username==null ){
// this.snack.open('username is required !!', '',{
//   duration:3000,
// });
//        return;
//      }
//      if(this.loginData.password.trim()==''||this.loginData.password==null ){
//       this.snack.open('password is required !!', '',{
//         duration:3000,
//       });
//              return;
//            }
//      this.login.generateToken(this.loginData).subscribe(
//       (data:any)=>{
//         console.log("success")
//         console.log(data)
//       },
//       (error:any)=>{
//         console.log('Error');
//     console.log(error);
    
//        });
//   }

}
