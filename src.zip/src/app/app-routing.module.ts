import { createComponent, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
 
import { ForbiddenComponent } from './components/forbidden/forbidden.component';
 import { NavbarComponent } from './components/navbar/navbar.component';
import { AuthorComponent } from './pages/author/author/author.component';
import { BlockComponent } from './pages/author/block/block.component';
import { CreateComponent } from './pages/author/create/create.component';
import { EditComponent } from './pages/author/edit/edit.component';
import { HomeComponent } from './pages/home/home.component';
import { LoginComponent } from './pages/login/login.component';
import { ReaderComponent } from './pages/reader/reader/reader.component';
import { SubscribeComponent } from './pages/reader/subscribe/subscribe.component';
import { UnsubscribeComponent } from './pages/reader/unsubscribe/unsubscribe.component';
import { SearchallbooksComponent } from './pages/searchallbooks/searchallbooks.component';
import { SignupComponent } from './pages/signup/signup.component';

const routes: Routes = [
 //{path:'', component:NavbarComponent},
  {path:'home', component:HomeComponent},
  {path:'signup', component:SignupComponent},
  {path:'login', component:LoginComponent},
  {path:'author', component:AuthorComponent} ,
  //canActivate:[AuthGuard], data:{roles:['AUTHOR']}},
  {path:'reader', component:ReaderComponent},
  //canActivate:[AuthGuard], data:{roles:['READER']}},
 {path:'create', component:CreateComponent},
  {path:'forbidden', component:ForbiddenComponent},
  {path:'edit', component:EditComponent},
   {path:'block', component:BlockComponent},
   {path:'searchallbooks', component:SearchallbooksComponent},
   {path:'subscribe', component:SubscribeComponent},
   {path:'unsubscribe', component:UnsubscribeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
