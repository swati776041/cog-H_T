import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Subscription } from '../model/subscription';

@Injectable({
  providedIn: 'root'
})
export class SubscriptionService {

  constructor(private httpClient:HttpClient) { }

  public subscribeBook(subscription:Subscription){
    return this.httpClient.post<Subscription>("http://ec2-18-181-85-188.ap-northeast-1.compute.amazonaws.com:8081/digitalbook/reader/2/subscribe/1", subscription);
  }
  public unsubscribeBook(subscription:Subscription){
    return this.httpClient.post<Subscription>("http://ec2-18-181-85-188.ap-northeast-1.compute.amazonaws.com:8081/digitalbook/reader/2/subscribe/cancel/1", subscription);
  }
}
