import { HttpErrorResponse } from '@angular/common/http';
import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Subscription } from 'src/app/model/subscription';
import { SubscriptionService } from 'src/app/services/subscription.service';

@Component({
  selector: 'app-unsubscribe',
  templateUrl: './unsubscribe.component.html',
  styleUrls: ['./unsubscribe.component.css']
})
export class UnsubscribeComponent {
  subscription:Subscription={
    date:'',
	time: '',
	bookID :0,
  authotId:0
  
  }
constructor(private subscriptionService: SubscriptionService){

}
ngOnInit():void{

}
unsubscribeBook(subscriptionForm:NgForm){
  this.subscriptionService.unsubscribeBook(this.subscription).subscribe(
    (response:Subscription) =>{
   console.log(response);
    },
    (error:HttpErrorResponse)=>{
      console.log(error);
      
    }
  );

}
}
