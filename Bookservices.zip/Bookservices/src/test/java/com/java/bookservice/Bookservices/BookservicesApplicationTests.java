package com.java.bookservice.Bookservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookservicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
