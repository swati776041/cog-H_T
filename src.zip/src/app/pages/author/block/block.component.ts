import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Book } from 'src/app/model/book.model';
import { BookService } from 'src/app/services/book.service';

@Component({
  selector: 'app-block',
  templateUrl: './block.component.html',
  styleUrls: ['./block.component.css']
})
export class BlockComponent implements OnInit{
  book:Book={
    title:'',
	category: '',
	image : '' ,
    price:0 ,
	publishDate: '' ,
    publisher: '', 
	content: '' ,
	authorId:0,
  active: true
  }
constructor(
   private bookService: BookService){

}
ngOnInit():void{

}
blockBook(bookForm:NgForm){
  this.bookService.blockBook(this.book).subscribe(
    (response:Book) =>{
      bookForm.reset();
    },
    (error:HttpErrorResponse)=>{
      console.log(error);
      
    }
  );

  
}
}
