import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Subscription } from '../model/subscription';

@Injectable({
  providedIn: 'root'
})
export class SubscriptionService {

  constructor(private httpClient:HttpClient) { }
  httpHeaderWithJwtToken(): HttpHeaders {
    let token = localStorage.getItem('token');

    console.log(token)
    const headers = new HttpHeaders()
      .set("Content-Type", "application/json")
      .set("Authorization", "Bearer " + token)
    return headers;
  }

 subscribeBook(subscription:Subscription): Observable<any>{
  let addBookUrl: string =  "http://ec2-43-207-34-217.ap-northeast-1.compute.amazonaws.com:8081/digitalbook/reader/2/subscribe/1";
  return this.httpClient.post(addBookUrl, subscription, { headers: this.httpHeaderWithJwtToken() });
    //return this.httpClient.post<Subscription>("http://ec2-43-207-34-217.ap-northeast-1.compute.amazonaws.com:8081/digitalbook/reader/2/subscribe/1", subscription);
  }
  public unsubscribeBook(subscription:Subscription): Observable<any>{
    let addBookUrl: string =  "http://ec2-43-207-34-217.ap-northeast-1.compute.amazonaws.com:8081/digitalbook/reader/2/subscribe/cancel/1";
  return this.httpClient.post(addBookUrl, subscription, { headers: this.httpHeaderWithJwtToken() });
    //return this.httpClient.post<Subscription>("http://ec2-43-207-34-217.ap-northeast-1.compute.amazonaws.com:8081/digitalbook/reader/2/subscribe/cancel/1", subscription);
  }
}
