package com.java.demo;

public class Customer {
	int id;
	 String name;
	 String gender;
	 String city;
	 public Customer(int id,String name,String gender,String city)
	 {
	 	this.id = id;
	 	this.name = name;
	 	this.gender = gender;
	 	this.city = city;
	 }
	 
}
