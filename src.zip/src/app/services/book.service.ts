import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Book } from '../model/book.model';
import { UserAuthService } from './user-auth.service';

@Injectable({
  providedIn: 'root'
})
export class BookService {

  constructor(private httpClient:HttpClient, private authservice:UserAuthService) { }
  httpHeaderWithJwtToken(): HttpHeaders {
    let token = localStorage.getItem('token');

    console.log(token)
    const headers = new HttpHeaders()
      .set("Content-Type", "application/json")
      .set("Authorization", "Bearer " + token)
    return headers;
  }

  addBook(book: Book): Observable<any> {
    let addBookUrl: string =  "http://ec2-43-207-34-217.ap-northeast-1.compute.amazonaws.com:8081/digitalbook/author/1/book";
    return this.httpClient.post(addBookUrl, book, { headers: this.httpHeaderWithJwtToken() });

  }
  public getAllBooks(){
    return this.httpClient.get<Book>("http://ec2-43-207-34-217.ap-northeast-1.compute.amazonaws.com:8081/digitalbooks/search/books")
  }
  public blockBook(book:Book):Observable<any>{
    let blockBookUrl: string =  "http://ec2-43-207-34-217.ap-northeast-1.compute.amazonaws.com:8081/digitalbook/author/1/book/1/blockyes";
    return this.httpClient.post(blockBookUrl, book, { headers: this.httpHeaderWithJwtToken() });
    
    //return this.httpClient.post<Book>("http://ec2-43-207-34-217.ap-northeast-1.compute.amazonaws.com:8081/digitalbook/author/1/book/1/blockyes", book);
  }
  public editBook(book:Book): Observable<any>{
    let editBookUrl: string =  "http://ec2-43-207-34-217.ap-northeast-1.compute.amazonaws.com:8081/digitalbook/author/1/book/1/";
    return this.httpClient.post(editBookUrl, book, { headers: this.httpHeaderWithJwtToken() });
     //return this.httpClient.post<Book>("http://ec2-43-207-34-217.ap-northeast-1.compute.amazonaws.com:8081/digitalbook/author/1/book/1/", book);
  }
  public deleteBook(id:number){
    let deleteBookUrl: string =  "http://ec2-43-207-34-217.ap-northeast-1.compute.amazonaws.com:8081/digitalbook/author/1/book/delete/";
    return this.httpClient.post(deleteBookUrl+id+"/", { headers: this.httpHeaderWithJwtToken() });

    // return this.httpClient.delete("http://ec2-43-207-34-217.ap-northeast-1.compute.amazonaws.com:8081/digitalbook/author/1/book/delete/"+id+"/")
  }
}
